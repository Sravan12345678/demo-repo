import os
import shutil
import sys

audio=['.m4a','.wma','.wac']
video=['.mp4','.wmv','.avi']
Image=['.jpg','.png']
Document=['.pdf','.docx']
software=['.exe','apk']

path ='C:\\Users\\panne\\Desktop\\File organizer\\'
files = os.listdir(path)
os.makedirs(path+'\\'+'audio',exist_ok=True)
os.makedirs(path+'\\'+'video',exist_ok=True)
os.makedirs(path+'\\'+'Image',exist_ok=True)
os.makedirs(path+'\\'+'Document',exist_ok=True)
os.makedirs(path+'\\'+'software',exist_ok=True)
os.makedirs(path+'\\'+'unknown',exist_ok=True)

def arrange(ext, newPath, path, file ):
    try:
        if ext in audio:
            shutil.move(newPath +"\\"+ file, path + "\\" + 'audio')
        elif ext in video:
            shutil.move(newPath +"\\"+ file, path + "\\" + 'video')
        elif ext in Image:
            shutil.move(newPath +"\\"+ file, path + "\\" + 'Image')
        elif ext in Document:
            shutil.move(newPath +"\\"+ file, path + "\\" + 'Document')
        elif ext in software:
            shutil.move(newPath +"\\"+ file, path + "\\" + 'software')
        else:
            shutil.move(newPath +"\\"+ file, path + "\\" + 'unknown')
    except Exception as ex:
        print(ex)
   


for file in files:
    print(files)
    extension = os.path.splitext(file)[1]
    if extension == "":
        files1 = os.listdir(path+"\\"+file)
        print(files1)
        for file1 in files1:
            ext = os.path.splitext(file1)[1]
            Newpath=path+"\\"+file
            arrange(ext, Newpath, path, file1)

    else:
        arrange(extension, path, path,  file)






