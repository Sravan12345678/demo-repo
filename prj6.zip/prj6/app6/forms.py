from django import forms
from app6.models import Patient,Doctor,Appointment,Bill

class PatientForm(forms.ModelForm):
    class Meta:
         model = Patient
         fields = '__all__'

class DoctorForm(forms.ModelForm):
    class Meta:
        model = Doctor
        fields = '__all__'

class AppointmentForm(forms.ModelForm):
    class Meta:
         model = Appointment
         exclude = ['created_at']  # match to your model’s fields


class BillForm(forms.ModelForm):
    class Meta:
        model = Bill
        fields = '__all__'
