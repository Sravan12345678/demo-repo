from django.shortcuts import render,redirect


from app6.forms import PatientForm ,AppointmentForm , BillForm , DoctorForm
from app6.models import Patient,Doctor,Appointment,Bill

# Create your views here.
def home(request):
    context={'total_patient':Patient.objects.count(),
             'total_Doctors':Doctor.objects.count(),
             'total_Appointment':Appointment.objects.count(),
             'total_bills':Bill.objects.count()
    }
    return render(request,'home.html',context)

def patient_list(request):
    patients=Patient.objects.all()
    return render(request,'patient_list.html',{'patients': patients})

def add_patient(request):
      if request.method == 'POST':
          form=PatientForm(request.POST)
          if form.is_valid():
            form.save()
            return redirect('patient_list')
      else:
           form=PatientForm()
      return render(request, 'add_patient.html', {'form': form})

def appointment_list(request):
    appointment=Appointment.objects.all()
    return render(request,'appointment_list.html',{'appointment':appointment})

def add_appointment(request):
    if request.method == 'POST':
        form=AppointmentForm(request.POST)
        if form.is_valid():
           form.save()
        return redirect('appointment_list')
    else:
     form=AppointmentForm()
    return render(request,'add_appointment.html',{'form': form})

def bill_list(request):
    bills=Bill.objects.all()
    return render(request,'bill_list.html',{'bills':bills})

def add_bill(request):
    if request.method == 'POST':
        form = BillForm(request.POST)
        if form.is_valid():
         form.save()
         return redirect('bill_list')
    else:
        form=BillForm()
    return render(request,'add_bill.html',{'form':form})


def Doctor_list(request):
    doctors = Doctor.objects.all()
    return render(request,'doctor_list.html',{'doctors': doctors})

def add_doctor(request):
    if request.method == 'POST':
        form =DoctorForm(request.POST)
        if form.is_valid():
         form.save()
         return redirect('doctor_list')
    else:
        form=DoctorForm()
    return render(request,'add_doctor.html',{'form':form})