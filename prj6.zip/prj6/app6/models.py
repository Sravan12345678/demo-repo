from django.db import models

# Create your models here.
class Patient(models.Model):
    GENDER_CHOICES = (('M', 'Male'), ('F', 'Female'), ('O', 'Other'))
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=50)
    age = models.IntegerField()
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
    date_of_birth = models.DateField()
    phone = models.BigIntegerField(max_length=15)
    email = models.EmailField()
    address = models.TextField()
    emergency_contact_name = models.CharField(max_length=100)
    emergency_contact_number = models.BigIntegerField()

    def __str__(self):
       return f"{self.first_name}{self.last_name}"

class Doctor(models.Model):
    first_name = models.CharField(max_length=150)
    last_name = models.CharField(max_length=80)
    phone = models.BigIntegerField(max_length=30)
    email = models.EmailField(max_length=255, unique=True)
    specialization = models.CharField(max_length=150)
    address = models.TextField()

    def __str__(self):
       return f"{self.first_name}{self.last_name}"


class Appointment(models.Model):
    STATUS_CHOICES=[('Scheduled','scheduled'),
                    ('Completed','Completed'),
                    ('Cancelled','cancelled'),
                    ]
    patient=models.ForeignKey(Patient,on_delete=models.CASCADE)
    doctor=models.ForeignKey(Doctor,on_delete=models.CASCADE)
    appointment_date=models.DateTimeField()
    status=models.CharField(max_length=100,choices=STATUS_CHOICES)
    description=models.TextField(blank=True, null=True)



    def __str__(self):
        return f"Appointment for {self.patient} with Dr{self.doctor}"


class Bill(models.Model):
    patient_name=models.ForeignKey(Patient,on_delete=models.CASCADE)
    doctor=models.ForeignKey(Doctor,on_delete=models.CASCADE)
    paid=models.BooleanField(default=False)
    Payment=models.DateTimeField()
    Total_amount=models.DecimalField(max_digits=10,decimal_places=2)

    def __str__(self):
         return f"Bill for {self.patient_name}"