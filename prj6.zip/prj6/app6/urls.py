from django.urls import path
from app6 import views
from django.contrib import admin


urlpatterns=[
    path('admin/',admin.site.urls),
    path('',views.home,name='home'),
    path('patients/',views.patient_list,name='patient_list'),
    path('patients/add/',views.add_patient,name='add_patient'),
    path('doctors/',views.Doctor_list,name='doctor_list'),
    path('doctor/add/',views.add_doctor,name='add_doctor'),
    path('appointment/',views.appointment_list,name='appointment_list'),
    path('appointment/add/',views.add_appointment,name='add_appointment'),
    path('bills/', views.bill_list, name='bill_list'),
    path('bills/add/', views.add_bill, name='add_bill'),

]