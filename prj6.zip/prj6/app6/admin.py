from django.contrib import admin
from app6.models import  Appointment, Patient,Doctor,Bill

# Register your models here.

admin.site.register(Patient)
admin.site.register(Doctor)
admin.site.register(Appointment)
admin.site.register(Bill)